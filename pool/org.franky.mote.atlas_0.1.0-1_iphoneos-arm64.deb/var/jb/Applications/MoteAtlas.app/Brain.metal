#include <metal_stdlib>
using namespace metal;
// Model.h is prepended at runtime. One thread updates one postsynaptic neuron.
kernel void brainStep(device const uint *offsets [[buffer(0)]],
                      device const uint *presynaptic [[buffer(1)]],
                      device const float *weights [[buffer(2)]],
                      device const uint *flags [[buffer(3)]],
                      device const AtlasState *old [[buffer(4)]],
                      device AtlasState *next [[buffer(5)]],
                      constant AtlasInputs &p [[buffer(6)]],
                      uint i [[thread_position_in_grid]]) {
    if (i >= p.neurons) return;
    float sum = 0.f;
    if (p.connected) {
        for (uint e = offsets[i]; e < offsets[i+1]; ++e)
            sum += weights[e] * old[presynaptic[e]].rate;
    }
    next[i] = atlasUpdate(old[i], sum, flags[i], i, p);
}
