#pragma once
// Shared scalar equations: included by C++ and prepended to the Metal kernel.
#ifndef ATLAS_GPU
#include <cstdint>
typedef uint32_t uint;
#endif
struct AtlasState { float rate; float adaptation; };
struct AtlasInputs {
    uint neurons, tick;
    float lightLeft, lightRight, scent, startle, gain;
    uint connected;
};
inline uint atlasHash(uint x) {
    x ^= x >> 16; x *= 0x7feb352du; x ^= x >> 15;
    x *= 0x846ca68bu; x ^= x >> 16; return x;
}
inline AtlasState atlasUpdate(AtlasState old, float sum, uint flags, uint i, AtlasInputs p) {
    float stimulus = ((flags & 1u) ? p.lightLeft : 0.f)
                   + ((flags & 2u) ? p.lightRight : 0.f)
                   + ((flags & 4u) ? p.startle : 0.f)
                   + ((flags & 8u) ? p.scent : 0.f);
    float baseline = .010f + .008f * float(atlasHash(i ^ (p.tick / 15u)) & 65535u) / 65535.f;
    float drive = baseline + p.gain * sum + .65f * stimulus - .20f * old.adaptation;
    if (drive < 0.f) drive = 0.f;
    float target = drive / (.20f + drive);
    AtlasState next;
    next.rate = old.rate + (target - old.rate) * (1.f / 30.f / .22f);
    next.adaptation = old.adaptation + (old.rate - old.adaptation) * (1.f / 30.f / 3.f);
    return next;
}
