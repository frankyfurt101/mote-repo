(function(){
 'use strict';
 const data=window.NEURAL_CIRCUIT, api=window.NeuralCreature, $=id=>document.getElementById(id);
 let world=new api.World(data), running=true, brainVisible=false, tool='light', previous=0, accumulator=0;
 let width=1,height=1,dpr=1, history=[], report=null, worker=null, cameraStream=null, cameraTimer=null, cameraOn=false,motionOn=false;
 const canvas=$('arena'),ctx=canvas.getContext('2d'),chart=$('activity'),cg=chart.getContext('2d');
 const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const motes=Array.from({length:65},(_,i)=>{const r=api.random(i*17+53);return [r(),r(),r(),r()];});
 const ripples=[];const native=()=>!!window.webkit?.messageHandlers?.mote;
 const send=message=>window.webkit.messageHandlers.mote.postMessage(message);
 function resize(){const rect=canvas.getBoundingClientRect();width=rect.width;height=rect.height;dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);const r=chart.getBoundingClientRect();chart.width=Math.round(r.width*dpr);chart.height=Math.round(r.height*dpr);cg.setTransform(dpr,0,0,dpr,0,0);}
 function stimulus(x,y){x=api.clamp(x,0.06,0.94);y=api.clamp(y,0.12,0.88);world.stimulus(x,y,tool);ripples.push({x,y,age:0,type:tool});}
 canvas.addEventListener('pointerdown',e=>{const r=canvas.getBoundingClientRect();stimulus((e.clientX-r.left)/r.width,(e.clientY-r.top)/r.height);});
 canvas.addEventListener('keydown',e=>{let x=world.light?.x??.5,y=world.light?.y??.5;if(e.key===' '){e.preventDefault();$('pause').click();return;}const movement={ArrowLeft:[-.08,0],ArrowRight:[.08,0],ArrowUp:[0,-.08],ArrowDown:[0,.08]}[e.key];if(movement){e.preventDefault();stimulus(x+movement[0],y+movement[1]);}});
 function setTool(value){tool=value;$('light').setAttribute('aria-pressed',String(value==='light'));$('threat').setAttribute('aria-pressed',String(value==='threat'));}
 $('light').onclick=()=>setTool('light');$('threat').onclick=()=>setTool('threat');
 function reset(){world=new api.World(data,$('wiring').value);history=[];accumulator=0;ripples.length=0;}
 $('reset').onclick=reset;
 $('pause').onclick=()=>{running=!running;$('pause').textContent=running?'Pause':'Resume';$('pause').setAttribute('aria-pressed',String(!running));accumulator=0;};
 $('show-brain').onclick=()=>{brainVisible=!brainVisible;$('show-brain').setAttribute('aria-pressed',String(brainVisible));$('show-brain').textContent=brainVisible?'Hide its nervous system':'See its nervous system';};
 $('wiring').onchange=()=>{const mode=$('wiring').value;reset();$('wiring-label').textContent=mode==='connectome'?'FlyWire circuit':mode==='shuffled'?'Shuffled circuit':'Synapses disconnected';$('wiring-description').textContent=mode==='connectome'?'A curated escape and steering circuit from the female fruit fly connectome.':mode==='shuffled'?`${Math.round(data.null_model.new_pair_fraction*100)}% of source pairs changed. Degrees, signed strengths, and sensory assignments are preserved.`:'All recurrent edges are removed. The same tonic drive, sensory input and body decoder remain.';};
 function blobGlow(x,y,r,color){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();}
 function drawCreature(){
  const b=world.brain,m=b.motor,t=world.time,s=Math.min(width,height)*.15,activity=b.mean;
  ctx.save();ctx.translate(world.x*width,world.y*height);ctx.rotate(world.angle+Math.PI/2);
  blobGlow(0,0,s*1.8,'rgba(248,218,145,0.12)');
  for(let side of [-1,1])for(let leg=0;leg<4;leg++){
   const phase=t*(1.9+activity)+leg*.85, sway=Math.sin(phase)*s*.16;
   ctx.beginPath();ctx.moveTo(side*s*.38,(leg-1.5)*s*.28);
   ctx.bezierCurveTo(side*s*(.85+Math.sin(phase)*.1),(leg-1.5)*s*.42,side*s*(1.05+leg*.06),(leg-1.5)*s*.55+sway,side*s*(.95+leg*.15),(leg-1.5)*s*.68+sway+s*.4);
   ctx.strokeStyle=`rgba(248,218,145,${.2+activity*.3})`;ctx.lineWidth=2;ctx.lineCap='round';ctx.stroke();
  }
  const pulse=reducedMotion?1:1+Math.sin(t*2.8)*.018;ctx.scale(pulse,1);
  const body=ctx.createRadialGradient(-s*.17,-s*.2,s*.05,0,0,s);
  body.addColorStop(0,'rgba(255,235,181,0.68)');body.addColorStop(.55,'rgba(248,218,145,0.22)');body.addColorStop(1,'rgba(248,218,145,0.03)');
  ctx.beginPath();ctx.ellipse(0,0,s*.6,s*.87,0,0,Math.PI*2);ctx.fillStyle=body;ctx.fill();ctx.strokeStyle='rgba(255,232,174,.62)';ctx.lineWidth=1.4;ctx.stroke();
  ctx.beginPath();ctx.ellipse(0,-s*.46,s*.44,s*.38,0,0,Math.PI*2);ctx.strokeStyle='rgba(255,236,186,.22)';ctx.stroke();
  for(let i=0;i<75;i++){const index=i*8%b.n,a=b.activity[index];const n=data.nodes[index];const x=Math.sin(i*2.399)*Math.sqrt(i/75)*s*.44,y=Math.cos(i*2.399)*Math.sqrt(i/75)*s*.68;
   if(i>0){ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(Math.sin((i-1)*2.399)*Math.sqrt((i-1)/75)*s*.44,Math.cos((i-1)*2.399)*Math.sqrt((i-1)/75)*s*.68);ctx.strokeStyle=`rgba(234,125,159,${.045+a*.15})`;ctx.lineWidth=.6;ctx.stroke();}
   ctx.beginPath();ctx.arc(x,y,1+a*2,0,Math.PI*2);ctx.fillStyle=`rgba(255,${Math.floor(170+a*65)},${Math.floor(170+a*40)},${.3+a*.7})`;ctx.fill();
  }
  // Body ornament is activity-driven; the overlay below shows actual graph edges.
  for(let side of [-1,1]){ctx.beginPath();ctx.ellipse(side*s*.22,-s*.49,s*.065,s*.09,side*.25,0,Math.PI*2);ctx.fillStyle='#123b5d';ctx.fill();ctx.beginPath();ctx.arc(side*s*.22-s*.012,-s*.51,s*.02,0,Math.PI*2);ctx.fillStyle='#fff0c7';ctx.fill();}
  ctx.beginPath();ctx.ellipse(0,s*.13,s*(.12+activity*.08),s*.23,0,0,Math.PI*2);ctx.fillStyle=`rgba(234,125,159,${.25+activity*.3})`;ctx.fill();
  ctx.restore();
 }
 const xvals=data.nodes.map(n=>n.pos?.[0]??0), yvals=data.nodes.map(n=>n.pos?.[1]??0);
 const xmin=Math.min(...xvals),xmax=Math.max(...xvals),ymin=Math.min(...yvals),ymax=Math.max(...yvals);
 const positions=data.nodes.map((n,i)=>[.13+(xvals[i]-xmin)/Math.max(1,xmax-xmin)*.74,.16+(yvals[i]-ymin)/Math.max(1,ymax-ymin)*.56]);
 function drawBrain(){if(!brainVisible)return;ctx.fillStyle='rgba(8,36,59,.72)';ctx.fillRect(0,0,width,height);const a=world.brain.activity;const edges=world.brain.edges;
  const stride=Math.max(1,Math.ceil(edges.length/1500));for(let k=0;k<edges.length;k+=stride){const [p,q,w]=edges[k],v=a[p];if(v<.06)continue;ctx.beginPath();ctx.moveTo(positions[p][0]*width,positions[p][1]*height);ctx.lineTo(positions[q][0]*width,positions[q][1]*height);ctx.strokeStyle=w<0?`rgba(121,182,223,${v*.12})`:`rgba(248,218,145,${v*.1})`;ctx.lineWidth=.6;ctx.stroke();}
  positions.forEach((p,i)=>{ctx.beginPath();ctx.arc(p[0]*width,p[1]*height,1+a[i]*2,0,Math.PI*2);ctx.fillStyle=`rgba(248,218,145,${.18+a[i]*.82})`;ctx.fill();});ctx.fillStyle='#d7edf2';ctx.font='12px -apple-system,sans-serif';ctx.fillText('All 668 cells · a sampled view of the actual edges',20,height-95);
 }
 function draw(){ctx.clearRect(0,0,width,height);const bg=ctx.createLinearGradient(0,0,width,height);bg.addColorStop(0,'#1d4c6b');bg.addColorStop(.55,'#123b5d');bg.addColorStop(1,'#092d4b');ctx.fillStyle=bg;ctx.fillRect(0,0,width,height);
  for(const [x,y,r,p]of motes){const px=(x+(reducedMotion?0:Math.sin(world.time*.045+p*8)*.02))*width,py=(y+(reducedMotion?0:Math.cos(world.time*.04+p*9)*.02))*height;ctx.beginPath();ctx.arc(px,py,.5+r*1.2,0,Math.PI*2);ctx.fillStyle=`rgba(204,233,238,${.1+r*.18})`;ctx.fill();}
  if(world.light){const x=world.light.x*width,y=world.light.y*height;blobGlow(x,y,55,'rgba(248,218,145,.16)');ctx.strokeStyle='rgba(248,218,145,.38)';ctx.lineWidth=1;ctx.beginPath();ctx.arc(x,y,9+Math.sin(world.time*2)*1.5,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fillStyle='#f8da91';ctx.fill();}
  if(world.shock)blobGlow(world.shock.x*width,world.shock.y*height,65,`rgba(234,125,159,${world.shock.strength*.19})`);
  ctx.beginPath();world.trail.forEach((p,i)=>{if(!i)ctx.moveTo(p[0]*width,p[1]*height);else ctx.lineTo(p[0]*width,p[1]*height);});ctx.strokeStyle='rgba(215,237,242,.1)';ctx.lineWidth=1;ctx.stroke();
  for(const ripple of ripples){ripple.age+=running?1/60:0;ctx.beginPath();ctx.arc(ripple.x*width,ripple.y*height,10+ripple.age*70,0,Math.PI*2);ctx.strokeStyle=ripple.type==='threat'?`rgba(234,125,159,${Math.max(0,.5-ripple.age*.4)})`:`rgba(248,218,145,${Math.max(0,.5-ripple.age*.4)})`;ctx.stroke();}while(ripples[0]?.age>1.5)ripples.shift();
  drawCreature();drawBrain();
  const r=chart.getBoundingClientRect();cg.clearRect(0,0,r.width,r.height);cg.beginPath();history.forEach((value,i)=>{const x=i/Math.max(1,history.length-1)*r.width,y=r.height-10-value*(r.height-20);i?cg.lineTo(x,y):cg.moveTo(x,y);});cg.strokeStyle='#3c8295';cg.lineWidth=1.8;cg.stroke();
 }
 let frames=0;function frame(time){const delta=Math.min(.1,Math.max(0,(time-previous)/1000));previous=time;if(running&&!document.hidden){accumulator+=delta;let steps=0;while(accumulator>=1/60&&steps<6){world.step();accumulator-=1/60;steps++;}if(steps===6)accumulator=0;}
  if(frames++%8===0){history.push(world.brain.mean);if(history.length>180)history.shift();$('activity-number').textContent=Math.round(world.brain.mean*100)+'%';$('clock').textContent=Math.floor(world.time/60)+':'+String(Math.floor(world.time%60)).padStart(2,'0');$('behavior').textContent=!running?'Resting':world.lastInput.threat>.2?'Feeling a disturbance':world.lastInput.left+world.lastInput.right>.25?'Sensing light':'Quiet water';}draw();requestAnimationFrame(frame);}
 function resultReady(result){report=result;$('comparison-status').textContent=`Eight matched trials finished. Mean steering-response difference: ${result.mean_steering_difference.toFixed(4)}. No better/worse ranking is inferred.`;$('export').hidden=false;$('compare').disabled=false;$('compare').textContent='Run matched trials';}
 $('compare').onclick=async()=>{if($('compare').disabled)return;$('compare').disabled=true;$('comparison-status').textContent='Running the same stimulus stream through both circuits…';$('compare').textContent='Comparing…';
  try{if(typeof Worker!=='undefined'&&!window.MOTE_STANDALONE){worker=new Worker('trials-worker.js');worker.onmessage=e=>{if(e.data.kind==='progress')$('comparison-status').textContent=`Matched trial ${e.data.done} of 8`;else if(e.data.kind==='result'){resultReady(e.data.result);worker.terminate();worker=null;}else{$('comparison-status').textContent='Trial failed: '+e.data.message;$('compare').disabled=false;worker.terminate();worker=null;}};worker.onerror=async()=>{worker?.terminate();worker=null;try{resultReady(await api.compare(data));}catch(error){$('comparison-status').textContent='Trial failed: '+error.message;$('compare').disabled=false;$('compare').textContent='Run matched trials';}};worker.postMessage('run');}else resultReady(await api.compare(data));}
  catch(error){$('comparison-status').textContent='Could not complete trials: '+error.message;$('compare').disabled=false;$('compare').textContent='Run matched trials';}
 };
 $('export').onclick=()=>{if(!report)return;if(native()){send({action:'export',data:report});return;}const blob=new Blob([JSON.stringify(report,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='mote-matched-trials.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
 function cameraStopped(){cameraStream?.getTracks().forEach(t=>t.stop());cameraStream=null;if(cameraTimer)clearInterval(cameraTimer);cameraTimer=null;cameraOn=false;world.sensor.left=0;world.sensor.right=0;world.sensor.threat=0;$('camera').textContent='Enable camera senses';}
 $('camera').onclick=async()=>{if(native()){send({action:'camera',enabled:!cameraOn});return;}if(cameraOn){cameraStopped();$('sensor-status').textContent='Camera stopped.';return;}
  try{if(!navigator.mediaDevices?.getUserMedia)throw new Error('Camera requires HTTPS/localhost, or the native iPhone app.');cameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment',width:160,height:120},audio:false});const video=document.createElement('video');video.muted=true;video.playsInline=true;video.srcObject=cameraStream;await video.play();const tiny=document.createElement('canvas');tiny.width=32;tiny.height=24;const g=tiny.getContext('2d',{willReadFrequently:true});let last=null;cameraOn=true;$('camera').textContent='Stop camera senses';$('sensor-status').textContent='Camera senses on. Only left/right brightness and frame change enter the circuit; frames stay here.';
   cameraTimer=setInterval(()=>{g.drawImage(video,0,0,32,24);const pixels=g.getImageData(0,0,32,24).data;let left=0,right=0,movement=0;for(let j=0;j<768;j++){const v=(pixels[j*4]+pixels[j*4+1]+pixels[j*4+2])/765;(j%32<16)?left+=v:right+=v;if(last)movement+=Math.abs(v-last[j]);}last=Float64Array.from({length:768},(_,j)=>(pixels[j*4]+pixels[j*4+1]+pixels[j*4+2])/765);window.moteSensors({left:left/384,right:right/384,threat:movement/768*3});},100);
  }catch(e){cameraStopped();$('sensor-status').textContent=e.message;}
 };
 function motionHandler(e){if(motionOn&&Number.isFinite(e.gamma))world.sensor.tilt=api.clamp(e.gamma/45,-1,1);}
 $('motion').onclick=async()=>{if(native()){send({action:'motion',enabled:!motionOn});return;}if(motionOn){motionOn=false;window.removeEventListener('deviceorientation',motionHandler);world.sensor.tilt=0;$('motion').textContent='Enable tilt senses';$('sensor-status').textContent='Tilt stopped.';return;}
  try{if(typeof DeviceOrientationEvent==='undefined')throw new Error('Tilt is available on a sensor-equipped phone.');if(typeof DeviceOrientationEvent.requestPermission==='function'&&await DeviceOrientationEvent.requestPermission()!=='granted')throw new Error('Motion permission was declined. Touch still works.');motionOn=true;window.addEventListener('deviceorientation',motionHandler);$('motion').textContent='Stop tilt senses';$('sensor-status').textContent='Tilt senses on. Tilt stimulates the circuit; it does not directly steer the body.';}catch(e){$('sensor-status').textContent=e.message;}
 };
 window.moteSensors=input=>{for(const key of ['left','right','threat','tilt'])if(Number.isFinite(input[key]))world.sensor[key]=api.clamp(input[key],key==='tilt'?-1:0,key==='tilt'?1:2);};
 window.moteNativeStatus=status=>{if(typeof status.camera==='boolean'){cameraOn=status.camera;$('camera').textContent=cameraOn?'Stop camera senses':'Enable camera senses';if(!cameraOn)window.moteSensors({left:0,right:0,threat:0});}if(typeof status.motion==='boolean'){motionOn=status.motion;$('motion').textContent=motionOn?'Stop tilt senses':'Enable tilt senses';if(!motionOn)world.sensor.tilt=0;}if(status.message)$('sensor-status').textContent=status.message;};
 window.moteStatus=()=>({mode:world.mode,time:world.time,position:[world.x,world.y],meanActivity:world.brain.mean,motor:{...world.brain.motor},input:{...world.lastInput},neurons:data.nodes.length,edges:world.brain.edges.length,cameraOn,motionOn,report});
 document.addEventListener('visibilitychange',()=>{accumulator=0;if(document.hidden&&!native()){cameraStopped();motionOn=false;window.removeEventListener('deviceorientation',motionHandler);world.sensor.tilt=0;$('motion').textContent='Enable tilt senses';}});
 window.addEventListener('resize',resize);resize();requestAnimationFrame(frame);
})();
