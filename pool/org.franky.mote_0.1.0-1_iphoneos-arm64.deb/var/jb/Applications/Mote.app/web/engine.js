/* Original rate-neuron model and creature world. Connectivity is separate data. */
(function (root) {
  'use strict';
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  function random(seed) {
    let s = seed >>> 0;
    return () => { s += 0x6D2B79F5; let t = Math.imul(s ^ s >>> 15, 1 | s); t ^= t + Math.imul(t ^ t >>> 7, 61 | t); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  }
  class Brain {
    constructor(data, mode = 'connectome', seed = 19) {
      this.data = data; this.mode = mode; this.seed = seed; this.rng = random(seed);
      this.n = data.nodes.length;
      this.activity = new Float64Array(this.n); this.next = new Float64Array(this.n);
      this.adaptation = new Float64Array(this.n); this.drive = new Float64Array(this.n);
      this.bias = Float64Array.from({length: this.n}, () => 0.11 + this.rng() * 0.05);
      this.tau = Float64Array.from({length: this.n}, () => 0.065 + this.rng() * 0.035);
      this.groups = {};
      data.nodes.forEach((node, i) => {
        (this.groups[node.role] ||= []).push(i);
        if (['lc4', 'lplc2'].includes(node.role)) (this.groups['sensory_' + node.side] ||= []).push(i);
        if (['dna01', 'dna02'].includes(node.role)) (this.groups['steer_' + node.side] ||= []).push(i);
      });
      const edges = mode === 'shuffled' ? data.shuffled_edges : mode === 'disconnected' ? [] : data.edges;
      this.edges = edges;
      const incoming = new Float64Array(this.n);
      for (const [a,b,w] of edges) incoming[b] += Math.abs(w);
      this.pre = Int32Array.from(edges, e => e[0]); this.post = Int32Array.from(edges, e => e[1]);
      this.weight = Float64Array.from(edges, e => e[2] / Math.max(1, incoming[e[1]]));
      this.elapsed = 0; this.mean = 0; this.motor = {forward:0, reverse:0, left:0, right:0, escape:0};
    }
    meanGroup(name) { const indices = this.groups[name] || []; let sum = 0; for (const i of indices) sum += this.activity[i]; return indices.length ? sum / indices.length : 0; }
    stimulate(name, value) { for (const i of this.groups[name] || []) this.drive[i] += value; }
    step(input = {}, dt = 1/60) {
      this.drive.fill(0);
      // These sensory placements are our engineering choices, not measured anatomy.
      this.stimulate('sensory_left', clamp(input.left || 0, 0, 2) * 0.9);
      this.stimulate('sensory_right', clamp(input.right || 0, 0, 2) * 0.9);
      this.stimulate('lc4', clamp(input.threat || 0, 0, 2) * 1.1);
      this.stimulate('lplc2', clamp(input.threat || 0, 0, 2) * 0.75);
      const tilt = clamp(input.tilt || 0, -1, 1);
      this.stimulate(tilt < 0 ? 'sensory_left' : 'sensory_right', Math.abs(tilt) * 0.6);
      for (let i = 0; i < this.n; i++) this.next[i] = this.drive[i];
      for (let e = 0; e < this.pre.length; e++) this.next[this.post[e]] += this.activity[this.pre[e]] * this.weight[e] * 1.65;
      let sum = 0;
      for (let i = 0; i < this.n; i++) {
        const noise = (this.rng() - 0.5) * 0.10;
        const current = this.next[i] + this.bias[i] + noise - this.adaptation[i];
        const target = Math.max(0, Math.tanh(current * 1.6));
        const value = this.activity[i] + (target - this.activity[i]) * Math.min(1, dt / this.tau[i]);
        this.activity[i] = clamp(value, 0, 1);
        this.adaptation[i] += (0.42 * value - this.adaptation[i]) * Math.min(1, dt / 0.75);
        sum += this.activity[i];
      }
      this.elapsed += dt; this.mean = sum / this.n;
      this.motor = {forward: this.meanGroup('dnp09'), reverse: this.meanGroup('mdn'), left: this.meanGroup('steer_left'), right: this.meanGroup('steer_right'), escape: this.meanGroup('gf')};
      return this.motor;
    }
  }
  class World {
    constructor(data, mode = 'connectome', seed = 19) {
      this.brain = new Brain(data, mode, seed); this.mode = mode; this.seed = seed;
      this.x = 0.5; this.y = 0.53; this.angle = -1.3; this.time = 0;
      this.light = {x:0.76, y:0.31, strength:0.8}; this.shock = null;
      this.sensor = {left:0, right:0, threat:0, tilt:0}; this.trail = [];
      this.distance = 0; this.lastInput = {}; this.speed = 0; this.turn = 0;
    }
    sense() {
      let left = 0.03, right = 0.03, threat = 0;
      if (this.light) {
        const dx = this.light.x - this.x, dy = this.light.y - this.y;
        const bearing = Math.atan2(dy, dx) - this.angle;
        const strength = this.light.strength * Math.exp(-Math.hypot(dx, dy) * 2.6);
        left += strength * (0.52 + 0.48 * Math.cos(bearing + 0.6));
        right += strength * (0.52 + 0.48 * Math.cos(bearing - 0.6));
      }
      if (this.shock) threat = this.shock.strength * Math.exp(-Math.hypot(this.shock.x-this.x, this.shock.y-this.y) * 3);
      return {left:clamp(left + this.sensor.left * 0.65,0,2), right:clamp(right + this.sensor.right * 0.65,0,2), threat:clamp(threat + this.sensor.threat * 0.7,0,2), tilt:this.sensor.tilt};
    }
    step(dt=1/60) {
      this.lastInput = this.sense(); const m = this.brain.step(this.lastInput, dt);
      // This body decoder is authored. There is no direct steer-to-pointer routine.
      this.turn = (m.right - m.left) * 11 + (m.escape - m.reverse) * 0.65;
      this.speed = clamp(0.027 + m.forward * 0.15 - m.reverse * 0.12 + m.escape * 0.035, -0.055, 0.13);
      this.angle += this.turn * dt;
      const dx = Math.cos(this.angle) * this.speed * dt, dy = Math.sin(this.angle) * this.speed * dt;
      this.x += dx; this.y += dy; this.distance += Math.hypot(dx,dy);
      if (this.x < 0.07 || this.x > 0.93) { this.angle = Math.PI - this.angle; this.x = clamp(this.x,0.07,0.93); }
      if (this.y < 0.1 || this.y > 0.9) { this.angle = -this.angle; this.y = clamp(this.y,0.1,0.9); }
      if (this.shock) { this.shock.strength *= Math.exp(-dt * 0.85); if (this.shock.strength < 0.015) this.shock = null; }
      this.time += dt;
      if (Math.floor(this.time * 15) !== Math.floor((this.time-dt) * 15)) { this.trail.push([this.x,this.y]); if (this.trail.length>170) this.trail.shift(); }
    }
    stimulus(x,y,kind='light') { if(kind==='threat') this.shock={x,y,strength:1.7}; else this.light={x,y,strength:1}; }
  }
  async function compare(data, onProgress = () => {}) {
    const results=[];
    for(let trial=0;trial<8;trial++) {
      const a=new Brain(data,'connectome',100+trial), b=new Brain(data,'shuffled',100+trial);
      const stimulus = random(900+trial); let divergence=0, meanA=0, meanB=0;
      for(let step=0;step<480;step++) {
        const input={left:(step<120?0.7:step<240?0.1:0.3)+stimulus()*0.1, right:(step<120?0.1:step<240?0.7:0.3)+stimulus()*0.1, threat:step>=300&&step<360?1:0, tilt:0};
        const ma=a.step(input), mb=b.step(input);
        divergence += Math.abs(ma.left-ma.right-mb.left+mb.right);
        meanA+=a.mean;meanB+=b.mean;
      }
      results.push({seed:100+trial,seconds:8,mean_activity_connectome:meanA/480,mean_activity_shuffled:meanB/480,mean_steering_difference:divergence/480});
      onProgress(trial+1,8); await new Promise(resolve=>setTimeout(resolve,0));
    }
    return {kind:'matched open-loop stimulus response; no task-fitness score',dt:1/60,trials:results,
      mean_steering_difference:results.reduce((s,x)=>s+x.mean_steering_difference,0)/results.length,
      conclusion:'Difference demonstrates model sensitivity to wiring. It does not establish biological superiority or animal-like behavior.',
      source_sha256:data.provenance.source_sha256,null_model:data.null_model};
  }
  const api={Brain,World,compare,random,clamp};
  if(typeof module!=='undefined'&&module.exports) module.exports=api; else root.NeuralCreature=api;
})(typeof window!=='undefined'?window:globalThis);
