importScripts('circuit.js','engine.js');
self.onmessage=async()=>{try{const result=await NeuralCreature.compare(NEURAL_CIRCUIT,(done,total)=>postMessage({kind:'progress',done,total}));postMessage({kind:'result',result});}catch(error){postMessage({kind:'error',message:error.message});}};
